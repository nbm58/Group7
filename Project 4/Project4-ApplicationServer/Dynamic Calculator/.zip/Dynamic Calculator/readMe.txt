Start Server:
=============
java web.SimpleWebServer

Start Calculator:
=================
java dynNet.dynCalculator.DynCalculator